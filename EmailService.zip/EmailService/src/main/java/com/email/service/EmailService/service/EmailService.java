package com.email.service.EmailService.service;

import com.email.service.EmailService.dto.EmailRequest;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public abstract class EmailService {

    public List<String> send(List<EmailRequest> request) {

        List<String> res = new ArrayList<>();
        for (EmailRequest req : request) {
            EmailProcessor processor = getProcessor();
            processor.send(req);
            res.add("Email Processed Succesfully to end user! " + processor);
        }

        return res;

    }

    @Lookup
    protected abstract EmailProcessor getProcessor();

}
