package com.email.service.EmailService.controller;


import com.email.service.EmailService.dto.EmailRequest;
import com.email.service.EmailService.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EmailController {

    @Autowired
    private EmailService service;


    @PostMapping("/send")
    public ResponseEntity<List<String>> send(@RequestBody List<EmailRequest> request)
    {
        return new ResponseEntity<>(service.send(request), HttpStatus.CREATED);
    }
}
