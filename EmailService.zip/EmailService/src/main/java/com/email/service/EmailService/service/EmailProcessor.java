package com.email.service.EmailService.service;


import com.email.service.EmailService.dto.EmailRequest;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class EmailProcessor {

    public void send (EmailRequest request)
    {
        System.out.println("Processing Email :" + this);

        try
        {
            Thread.sleep(2000);
        }
        catch (InterruptedException e)
        {
            Thread.currentThread().interrupt();
        }

        System.out.println("Email Sent SuccessFully! " + this);
    }
}
